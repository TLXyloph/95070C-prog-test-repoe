#include "main.h"
#include  "autonomous.h"



void leftBtn(){

}
void centerBtn(){

}
void rightBtn(){

}

void initialize() {
	pros::lcd::initialize();
	pros::lcd::register_btn0_cb(leftBtn);
	pros::lcd::register_btn1_cb(centerBtn);
	pros::lcd::register_btn2_cb(rightBtn);
	FBarL.set_brake_mode(MOTOR_BRAKE_HOLD);
	FBarR.set_brake_mode(MOTOR_BRAKE_HOLD);
	BRLift.set_brake_mode(MOTOR_BRAKE_HOLD);
	BLLift.set_brake_mode(MOTOR_BRAKE_HOLD);
	piston.set_value(true);
	//set to false if default position is the same

  autonSelector();
	//autonSelector();
}


void disabled() {}

void competition_initialize() {}

void autonomous() {
  switch(selected){
    case 0:
		disabledAuton(); //this sets us for no autonomous
		break;
    case 1:
	    rightElimsAuton(); //we use this auton on the right for elims (gets us 1 side numogo and 1 amogo in the back)
		break;
    case 2:
		rightspeedelims(); //this is for when we have a bot faster than us we have a higher chance of failing but a higher chance of getting the side numogo
		break;
    case 3:
		AWP_L(); //gives us the left awp and tries to grab the side numogo after
		break;
    case 4:
		godAWPR();
		break;
    case 5:
		//wont use as much will swap later
		AutoGoMid(); //we are in the corner and allows us to go straight for the middle goal
		break;
    case 6:
		rightuno(); //gets only the right numogo
		break;
    case 7:
		leftuno();
		break;
	case 8:
		Test1();
		break;
	case 9:
		Test2(); 
		break;
	case 10:
		Test3(); 
		break;
	case 11:
		AWPR(); 
		break;	
	default:
		return;
   }
}

const int NUM_HEIGHTS = 3;
const int height1 = 0;
const int height2 = 700;
const int height3 = 1500;
double spd=-2;

const int heights[NUM_HEIGHTS] = {height1, height2,height3};
const int heights2[NUM_HEIGHTS] = {0, 700,1800};

int x = 0;


bool climb=0;
std::string boardtglstr = "No Board";

/*
void my_task_fn(void* param) {
	std::string t =std::to_string( (FrontLeft.get_temperature()+FrontRight.get_temperature()+ BackLeft.get_temperature()+ BackRight.get_temperature()+FBarR.get_temperature()+ FBarL.get_temperature()+ BRLift.get_temperature()+ BLLift.get_temperature())/8);
	control.print(1, 1, t.c_str());
		delay(200);
		// ...
}

*/

double GetMaxTemperature() {
	std::vector<double> temps;
	std::vector<std::string> motor{"FL", "FR", "BL", "BR", "FBL", "FBR", "BLL","BLR"};
	temps.push_back(FrontLeft.get_temperature());
	temps.push_back(FrontRight.get_temperature());
	temps.push_back(BackLeft.get_temperature());
	temps.push_back(BackRight.get_temperature());
	temps.push_back(FBarL.get_temperature());
	temps.push_back(FBarR.get_temperature());
	temps.push_back(BLLift.get_temperature());
	temps.push_back(BRLift.get_temperature());

	double max_temp = temps[0];
	int idx = 0;
	for (int i = 1; i < temps.size(); i++) {
		if (temps[i] > max_temp) {
			max_temp = temps[i];
			idx = i;
		}
	}
	std::string s = "MaxTemp: " + std::to_string(max_temp);
	control.print(0, 1, "MaxTemp: %.1f, %s", max_temp, motor[idx]);

	pros::lcd::print(0, "MaxTemp: %.1f", max_temp);
  return max_temp;
}


void opcontrol() {
	master.clear();
	control.clear();
	BRLift.set_brake_mode(MOTOR_BRAKE_HOLD);
	BLLift.set_brake_mode(MOTOR_BRAKE_HOLD);
	FBarL.set_brake_mode(MOTOR_BRAKE_HOLD);
	FBarR.set_brake_mode(MOTOR_BRAKE_HOLD);
  	//piston.set_value(true);
 	int goalHeight = 0;
	int bGoalHeight = 0;
	double multiplier = 2;
	FBarL.set_zero_position(0); // initialize FBarL
	FBarR.set_zero_position(0); // initialize FBarR

  while (true){
		GetMaxTemperature();
		auto power = control.get_analog(ANALOG_LEFT_Y);
		auto turn = control.get_analog(ANALOG_LEFT_X);
		auto powerx = control.get_analog(ANALOG_RIGHT_Y);
		auto turnx= control.get_analog(ANALOG_RIGHT_X);
		if (abs(power) > 0 || abs(turn)>0){
			driverControl(multiplier*power+0.5*multiplier*turn, multiplier*power-0.5*multiplier*turn);
  		}
		else {
			double multiplierx = 0.75;
			driverControl(multiplierx*powerx+multiplierx*turnx, multiplierx*powerx-multiplierx*0.7*turnx);
		}
		if(control.get_digital(E_CONTROLLER_DIGITAL_DOWN)){
			fourbarmoveabsolute(1000,40);
		}

		if (control.get_digital(E_CONTROLLER_DIGITAL_X)){
			piston.set_value(false);
      //pistonextend;
		}
		if (control.get_digital(E_CONTROLLER_DIGITAL_B)){
			piston.set_value(true);
      //pistonretract;
		}

    if (RUp.changedToPressed() && goalHeight < NUM_HEIGHTS - 1) {
      goalHeight++;
      liftControl->setTarget(heights[goalHeight]);
    } else if (RDown.changedToPressed() && goalHeight > 0) {
      goalHeight--;
      liftControl->setTarget(heights[goalHeight]);
    }
	if (control.get_digital(E_CONTROLLER_DIGITAL_L1)) {
      fourbarmove(120);

    } else if (control.get_digital(E_CONTROLLER_DIGITAL_L2)) {
      fourbarmove(-120);
    } else {
	  fourbarmove(0);
	}
	if(control.get_digital(E_CONTROLLER_DIGITAL_A)){
		multiplier=0.75;
		BackRight.set_brake_mode(MOTOR_BRAKE_HOLD);
		BackLeft.set_brake_mode(MOTOR_BRAKE_HOLD);
		FrontLeft.set_brake_mode(MOTOR_BRAKE_HOLD);
		FrontRight.set_brake_mode(MOTOR_BRAKE_HOLD);
	}else{
		multiplier=2;
		BackRight.set_brake_mode(MOTOR_BRAKE_COAST);
		BackLeft.set_brake_mode(MOTOR_BRAKE_COAST);
		FrontLeft.set_brake_mode(MOTOR_BRAKE_COAST);
		FrontRight.set_brake_mode(MOTOR_BRAKE_COAST);
	}

	if(LUp.changedToPressed() && bGoalHeight < NUM_HEIGHTS-1){
		bGoalHeight++;
		liftControl->setTarget(heights[bGoalHeight]);
	} else if (LDown.changedToPressed() && bGoalHeight > 0) {
		bGoalHeight--;
		liftControl->setTarget(heights[bGoalHeight]);
	}
	if (control.get_digital(E_CONTROLLER_DIGITAL_R2)){
		bliftmove(-135);

	} else if (control.get_digital(E_CONTROLLER_DIGITAL_R1)) {
		bliftmove(135);

	} else {
		bliftmove(0);
	}

//pros::delay(20);
	pros:delay(5);

  }
}
