#include "../include/main.h"
#include "../include/functions.h"
#include "pid.h"

////////////////////////////////////////////
//DO THE GEAR RATIO THINGY
////////////////////////////////////////////////
std::shared_ptr<AsyncPositionController<double, double>> liftControl =
    AsyncPosControllerBuilder().withMotor({BRPort,BLPort}).build();
std::shared_ptr<AsyncPositionController<double, double>> fourbar =
    AsyncPosControllerBuilder().withMotor({FBRPort,FBLPort}).build();

//This file has all of the autonomous
void disabledAuton(){

}

void skills(){
  //non existant
  const double MOVE_INCH = -109; // move forward
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  drive(40,200);
  delay(1000);
  piston.set_value(true);
  drive(30,200);
}


void rightspeedelims(){

  const double MOVE_INCH = -109;
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
	drive(-40,200);
  delay(2750);
 	piston.set_value(true);
  delay(100);
  fourbarmoverelative(150,150);
  delay(1300);
  bliftmoverelative(-2000,100);
  drive(25,200);
  delay(2000);
  BotTurnRelative(-1100, 125);
  delay(1000);
  drive(-7,200);
  delay(1200);
  bliftmoverelative(-1700,100);
  delay(2300);
  drive(15.5,100);
 	delay(700);
  bliftmoverelative(3000, 100);
  delay(1500);
  drive(-10,200);
}

void AWP_L(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(300);
  bliftmoverelative(-2700,100);
  delay(3000);
  bliftmoverelative(2000,100);
  delay(3000);
  drive(6,170);
  delay(1000);
  BotTurnRelative(1350,100);
  delay(800);
  drive(-40,200);
  delay(2700);
  drive(-8,100);
  delay(1000);
  piston.set_value(true);
  delay(100);
  drive(38,200);
}

void AWPR(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
	auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(100);
  drive(-10,170); //THIS MOVES IT FORWARD
  delay(1000);
  drive(-8,80);
  delay(1000);
  piston.set_value(true);
  delay(2000);
  drive(19,180);
  delay(1000);
  piston.set_value(false);
}


void AutoGoMid() {
  const double MOVE_INCH = -109; // move forward
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(100);
  drive(-64, 200); // move X inches
  delay(4000);
  drive(-1, 100); // move X inches
  delay(500);
  piston.set_value(true);
  delay(100);
  fourbarmoverelative(150,200);
  delay(500);
  drive(50, 200); // move X inches
  delay(3000);
  fourbarmoverelative(-150,200);
  piston.set_value(false);
}

void left_to_middle() {
  const double MOVE_INCH = -109; // move forward
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  BotTurnRelative(-2250, 200);
  piston.set_value(false);
  delay(500);
  drive(-58, 200); // move X inches
  delay(3000);
  drive(-1, 100); // move X inches
  delay(500);
  piston.set_value(true);
  delay(100);
  fourbarmoverelative(150,200);
  delay(500);
  drive(50, 200); // move X inches
  delay(3000);
  fourbarmoverelative(-150,200);
  piston.set_value(false);
}

void rightuno() {
  const double MOVE_INCH = -109; // move forward
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  drive(-40, 200); // move X inches
  delay(2000);
  drive(-1, 100); // move X inches
  delay(400);
  piston.set_value(true);
  delay(100);
  fourbarmoverelative(300,200);
  delay(500);
  drive(35, 200); // move X inches
  delay(3000);
  fourbarmoverelative(-300,200);
  piston.set_value(false);
}

void leftuno() {
  const double MOVE_INCH = -109; // move forward
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  drive(-41, 200); // move X inches
  delay(2100);
  drive(-1, 100); // move X inches
  delay(200);
  piston.set_value(true);
  delay(100);
  fourbarmoverelative(300,200);
  delay(500);
  drive(35, 200); // move X inches
  delay(3000);
  fourbarmoverelative(-150,200);
  piston.set_value(false);
}

void godAWPR(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
	auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(100);
  drive(-17,170); //THIS MOVES IT FORWARD
  delay(1000);
  drive(-5,80);
  delay(700);
  piston.set_value(true);
  delay(200);
  BotTurnRelative(-2850,100);
  delay(1000);
  bliftmoverelative(-3700,135);
  delay(1700);
  drive(39,180);
  delay(2500);
  bliftmoverelative(3000,135);
  delay(1600);
  drive(-40,200);
}

void rightElimsAuton() {
const double MOVE_INCH = -109;
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
	drive(-39,200);
  delay(1950);
  drive(-5.5,100);
  delay(800);
 	piston.set_value(true);
  delay(100);
  fourbarmoverelative(150,150);
  delay(1300);
  bliftmoverelative(-2000,100);
  drive(25,200);
  delay(2000);
  BotTurnRelative(-1100, 125);
  delay(1000);
  drive(-7,200);
  delay(1200);
  bliftmoverelative(-1700,100);
  delay(2300);
  drive(15.5,100);
 	delay(700);
  bliftmoverelative(3000, 100);
  delay(1500);
  drive(-10,200);
}

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//CURRENTLY TESTING AUTONS
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

void Test1(){

}

void Test2(){

}

void Test3(){

  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
	auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(100);
  drive(-17,170); //THIS MOVES IT FORWARD
  delay(1000);
  drive(-5,80);
  delay(1000);
  piston.set_value(true);
  delay(2000);
  BotTurnRelative(-2900,100);
  delay(1000);
  bliftmoverelative(-3700,135);
  delay(1700);
  drive(39,180);
  delay(2700);
  bliftmoverelative(3000,135);
  delay(1700);
  drive(-40,200);
}





void AWPCARRY(){
  const double MOVE_INCH = -109;
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  bliftmoverelative(2000,100);
  BotTurnRelative(900,200);
  drive(-15,100);
  BotTurnRelative(900,200);
  drive(-70,150);
  piston.set_value(true);
  drive(20,200);
  //I DONT WANT TO USE THIS ;-;
  }


/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
//UNTESTED AUTON(S)
//// NOT (yet) INCLUDED IN CODE
///// PLEASE DONT ADD THEM INTO THE CODE
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////






void leftAWPandsnumogo() {
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
  	auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  	piston.set_value(false);
  	bliftmoverelative(-2250,100);
		delay(2000);
  	BotTurnRelative(900, 170); //makes the bot and goal be on the same line
  	drive(-42,200); //moves bot to the initial position of the numogo
  	delay(1500); //used so that the drives do not overlap and not allow the bot to allign itself with the numogo
  	drive(1,170); //makes sure that the goal is in the range of the clamp
  	delay(500); //delay is used so that the piston does not activate while the bot is not alligned with the numogo
  	piston.set_value(true);
  	drive(36,200); //drives us back to our side
}

/////////////////////////////////////////////////////////////////////////////////////
//WE HAVE THIS SO THAT WE HAVE A HIGHER CHANCE OF GETTING THE SIDE NUMOGO WHEN GOING AGAINST A SLIGHTLY FASTER OPPOSING ALLIANCE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void crashgrabanyside(){ //probably works
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false); //makes clamp unclamped so that the goal can fit into the clamp and we can grab it easily
  drive(-44,200); //drives us as fast as we can to side numogo so we can hopefully grab it before our slightly faster opposing team
  delay(2000); //used so that the piston does not engage before the bot gets to the side numogo
  piston.set_value(true); //piston is set so it clamps down on the goal and we can hopefully take it into our possestion
  delay(500); //delay is used again so that nothing overlaps during auton
  drive(37,200); //used so that we can drive back to our side if we are in possesion of the side numogo
}





/////////////////////////////////////////////////
////////////////////////////////////////////////////////
//DOING THIS FOR FUNZIES
/// NOT USING THIS FOR A WHILE
///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
void progskillz(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  drive(-40,170);
  //// NOT FINISHED IM JUST DOING THIS FOR FUNZIES

}




void rightAWPlineup(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
	auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  delay(100);
  drive(-10,170); //THIS MOVES IT FORWARD
  delay(1000);
  drive(-8,80);
  delay(1000);
  piston.set_value(true);
  delay(2000);
  drive(19,180);
  delay(1000);
///HAVENT STARTED THE LINEUP YET JUST AWP R FOR NOW
}



void leftdonumogo(){
  const double MOVE_INCH = -109; // sets the value of the double "MOVE_INCH"
  auto drive = [MOVE_INCH](double dist, double vel){BotMoveRelative(MOVE_INCH*dist, vel);};
  piston.set_value(false);
  drive(-41,200);
  delay(500);
  drive(-1,170);
  delay(400);
  piston.set_value(true);
  ////////////////////////////////////////////
  //UNFINISHED STILL NEEDS TO WRITE MORE LINES MOST LIKELY WILL NOT USE FOR 12/18
  //////////////////////////////////////////////////
}